<div class="qodef-column-inner">
	<?php if(is_active_sidebar('footer_text')) {
		dynamic_sidebar( 'footer_text' );
	} ?>
</div>