<?php if(startit_qode_show_comments()) : ?>
    <?php comments_template('', true); ?>
<?php endif; ?>
