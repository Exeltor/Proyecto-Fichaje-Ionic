<?php

//Get search HTML
add_action('qode_startit_before_page_header', 'startit_qode_get_search', 9);